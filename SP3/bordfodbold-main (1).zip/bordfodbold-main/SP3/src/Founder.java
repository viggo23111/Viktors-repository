import java.util.ArrayList;

public class Founder {
    private String name;
    public ArrayList<Team> teams= new ArrayList<>();

    public Founder(String name){
        this.name=name;
    }

    public String getName() {return name;}

}
